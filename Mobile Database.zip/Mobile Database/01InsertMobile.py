import pymysql

con=pymysql.connect(host='bjj0f0wa7m9tgjk83ytk-mysql.services.clever-cloud.com',user='ufba2pynfvxneylc',password='HhcDyPxZkiDYOlMlBgNv',database='bjj0f0wa7m9tgjk83ytk')
curs=con.cursor()

pid=int(input("Enter Prodid: "))
monm=input("Enter Model Name: ")
co=input("Enter Company: ")
conn=input("Enter Connectivity: ")
ra=int(input("Enter RAM: "))
ro=int(input("Enter ROM: "))
col=input("Enter Color: ")
scr=float(input("Enter Screen: "))
bat=int(input("Enter Battery: "))
pro=input("Enter Processor: ")
pr=float(input("Enter Price: "))
rat=float(input("Enter ratings: "))


data=curs.execute("insert into MOBILES values(%d,'%s','%s','%s',%d,%d,'%s',%.2f,%d,'%s',%.2f,%.2f)"%(pid,monm,co,conn,ra,ro,col,scr,bat,pro,pr,rat))
con.commit()
print('New mobile added successfully')

con.close()
