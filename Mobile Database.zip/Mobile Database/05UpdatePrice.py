import pymysql

con=pymysql.connect(host='bjj0f0wa7m9tgjk83ytk-mysql.services.clever-cloud.com',user='ufba2pynfvxneylc',password='HhcDyPxZkiDYOlMlBgNv',database='bjj0f0wa7m9tgjk83ytk')
curs=con.cursor()

pid=int(input('Enter Product Id: '))
curs.execute("select * from MOBILES where prodid=%d"%pid)
data=curs.fetchone()
if data:
    print(data)
    npr=float(input('Enter New Price: '))
    curs.execute("update MOBILES set price=%.2f where prodid=%d"%(npr,pid))
    con.commit()
    print('New Price Updated Successfully.')
else:
    print('Mobile Does Not Exist.')

con.close()