import pymysql

con=pymysql.connect(host='bjj0f0wa7m9tgjk83ytk-mysql.services.clever-cloud.com',user='ufba2pynfvxneylc',password='HhcDyPxZkiDYOlMlBgNv',database='bjj0f0wa7m9tgjk83ytk')
curs=con.cursor()
nm=input('Enter Model Name: ')
curs.execute("select * from MOBILES where modelnm='%s'"%nm)
data=curs.fetchone()

if data:
    print(data)

else:
    print("Mobile Not Found")


con.close()