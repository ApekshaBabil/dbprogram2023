import pymysql

con=pymysql.connect(host='bjj0f0wa7m9tgjk83ytk-mysql.services.clever-cloud.com',user='ufba2pynfvxneylc',password='HhcDyPxZkiDYOlMlBgNv',database='bjj0f0wa7m9tgjk83ytk')
curs=con.cursor()
monm=input('Enter ModelName: ')
curs.execute("select * from MOBILES where modelnm='%s'"%monm)
data=curs.fetchall()


if data:
    print(data)
    pur=input('Enter Purpose(Gaming/Office/Social,etc): ')
    curs.execute("update MOBILES set purpose='%s' where modelnm='%s'"%(pur,monm))
    con.commit()
    print("Data Entered Successfully.")

else:
    print('Mobile Does Not Exist')

con.close()

