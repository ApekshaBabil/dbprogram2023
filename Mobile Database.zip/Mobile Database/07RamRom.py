import pymysql

con=pymysql.connect(host='bjj0f0wa7m9tgjk83ytk-mysql.services.clever-cloud.com',user='ufba2pynfvxneylc',password='HhcDyPxZkiDYOlMlBgNv',database='bjj0f0wa7m9tgjk83ytk')
curs=con.cursor()

ra=int(input('Enter RAM: '))
ro=int(input('Enter ROM: '))
curs.execute("select * from MOBILES where ram=%d and rom=%d" %(ra,ro))
data=curs.fetchall()

if data:
    print(data)

else:
    print('Mobile Does Not Exist')

con.close()