import pymysql

con=pymysql.connect(host='bjj0f0wa7m9tgjk83ytk-mysql.services.clever-cloud.com',user='ufba2pynfvxneylc',password='HhcDyPxZkiDYOlMlBgNv',database='bjj0f0wa7m9tgjk83ytk')
curs=con.cursor()

pid=int(input('Enter product Id: '))
curs.execute("select * from MOBILES where prodid=%d"%pid)
data=curs.fetchone()
if data:
    print(data)
    cho=input('Do you really want to delete this Mobile?(yes/no): ')
    if cho=='yes':
        curs.execute("delete from MOBILES where prodid=%d"%pid)
        con.commit()
        print('Mobile Deleted Successfully.')
    else:
        print('Mobile deletion cancelled.')
else:
    print('Mobile not found')

con.close()
