import pymysql

con=pymysql.connect(host='bjj0f0wa7m9tgjk83ytk-mysql.services.clever-cloud.com',user='ufba2pynfvxneylc',password='HhcDyPxZkiDYOlMlBgNv',database='bjj0f0wa7m9tgjk83ytk')
curs=con.cursor()
com=input('Enter Company: ')
curs.execute("select * from MOBILES where company='%s'"%com)
data=curs.fetchall()

if data:
    print(data)
    pr=float(input('Enter Amount: '))
    curs.execute("update MOBILES set price=price-%.2f where company='%s'"%(pr,com))
    con.commit()
    print(data)
    print("Amount Reduces Successfully.")

else:
    print('Invalid Details. ')

con.close()