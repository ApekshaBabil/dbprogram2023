import pymysql

con=pymysql.connect(host='bjj0f0wa7m9tgjk83ytk-mysql.services.clever-cloud.com',user='ufba2pynfvxneylc',password='HhcDyPxZkiDYOlMlBgNv',database='bjj0f0wa7m9tgjk83ytk')
curs=con.cursor()


ro=int(input('Enter ROM: '))
curs.execute("select * from MOBILES where rom=%d order by rom desc" %ro)
data=curs.fetchall()
print(data)

con.close()