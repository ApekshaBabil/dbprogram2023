import pymysql

con=pymysql.connect(host='bjj0f0wa7m9tgjk83ytk-mysql.services.clever-cloud.com',user='ufba2pynfvxneylc',password='HhcDyPxZkiDYOlMlBgNv',database='bjj0f0wa7m9tgjk83ytk')
curs=con.cursor()

curs.execute("select company,count(modelnm),avg(price),avg(ratings) from MOBILES group by company")
data=curs.fetchall()
print(data)

con.close()
